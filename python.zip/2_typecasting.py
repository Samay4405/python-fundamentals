#Typecasting = The process of converting a variable from one data type to another
#               str(), int(), float(), bool()
name = "Samay"
age = 99
gpa = 6.9
is_student = True

print(type(name))
print(type(age))
print(type(gpa))
print(type(is_student))

gpa = int(gpa)
print(age)

gpa = float(gpa)
print(gpa)