#Arithmetic operators

a = 15
b = 4

result = a + b

print("Addition:", result)         
print("Subtraction:", a - b)      
print("Multiplication:", a * b)   
print("Division:", a / b)         
print("Floor Division:", a // b)  
print("Modulus:", a % b)          
print("Exponentiation:", a ** b)  
